package com.example.foodorder.view.splash;

public class SplashPresenter {

    private final SplashMVPView mSplashMVPView;

    public SplashPresenter(SplashMVPView mSplashMVPView) {
        this.mSplashMVPView = mSplashMVPView;
    }
}
