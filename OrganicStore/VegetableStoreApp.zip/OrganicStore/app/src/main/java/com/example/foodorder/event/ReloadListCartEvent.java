package com.example.foodorder.event;

public class ReloadListCartEvent {
}
