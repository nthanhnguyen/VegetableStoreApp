package com.example.foodorder.view.main;

public interface MainMVPView {
}
