package com.example.foodorder.view.food_detail;

public interface FoodDetailMVPView {
    void addToCartSuccess();
}
